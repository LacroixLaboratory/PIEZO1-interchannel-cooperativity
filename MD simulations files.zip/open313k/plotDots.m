clc;clear all;close all;

a = readtable('pro1_coord.csv');
b = readtable('pro2_coord.csv');

x = a.Var1';
y = a.Var2';
c = linspace(1,10,length(x));
scatter(x,y,25,c,'filled');
colorbar

hold on;
x = b.Var1';
y = b.Var2';
c = linspace(1,10,length(x));
scatter(x,y,25,c,'filled');
colorbar
%xlabel('X-axis','FontSize',30)
%ylabel('Y-axis','FontSize',30)
caxis([0, 7]);
ylim([0 512])
xlim([0 1024])
% zlabel('Z-axis','FontSize',34)
   


    